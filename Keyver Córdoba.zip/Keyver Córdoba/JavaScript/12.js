function relog(){
/*creó una variable new date y luego la q encargada de
* contener a hota, minutos y segundos...
*/
hr = new Date();
h = hr.getHours();
m = hr.getMinutes();
s = hr.getSeconds();
/*obtengo el id y luego uso la variables que contienen
 los datos que me darán la hora...
*/
document.getElementById
("reloj").innerHTML = "Hora: " + h+":"+m+":"+s;
/* setTimeout se va a encargar de q se actualize el
 reloj en tiempo real
 */
setTimeout("relog()")
}
/*creo la función encargada de mostrar la hora
 * 
 */
window.onload=function(){
relog();
}

//Fecha...
/* creo de de nuevo la variable new date
 *  y dos array para q me muestren el día y mes en el reloj
 * getMonth y getDay muestran las fechas de 0 a 6 y 0 a 11
 */
fecha = new Date();
dia = Array(7);
mes = Array(11);
  
dia[0]="Domingo";
dia[1]="Lunes";
dia[2]="Martes";
dia[3]="Miercoles";
dia[4]="Jueves";
dia[5]="Viernes";
dia[6]="Sabado";

mes[0]="Enero";
mes[1]="Febrero";
mes[2]="Marzo";
mes[3]="Abril";
mes[4]="Mayo";
mes[5]="Junio";
mes[6]="Julio";
mes[7]="Agosto";
mes[8]="Septiembre";
mes[9]="Octubre";
mes[10]="Noviembre";
mes[11]="Diciembre";
/*después de haberle asignado un número a la variable mes y dia
 * solo ahi q ponerlas junto a getDay y getMonth de la
 * manera que se muestra abajo... y en lugar de mostar
 * dia 1 mostrara el lunes y así mismo para el mes....
 */
document.write("Fecha: "+dia[fecha.getDay()]," "+fecha.getDate()," "+mes[fecha.getMonth()]," del "+fecha.getFullYear())

