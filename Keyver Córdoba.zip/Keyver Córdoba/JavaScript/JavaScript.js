//1.
alert("Hola Mundo!")
//2.
/*Con console.log nos comunicamos con
la consola y y lo que está entre
paréntesis será mostrado por ella.
*/
console.log("Click en cada boton...");
//3.
/*Aquí cree una función para cada radiobuttons
 * y al darle click al botón que los acompaña
 * la función se activará y mostrará lo que está
 * dentro de ella que es la alerta.
 */
function bk(){
alert("Basketball");
}
function soc(){
alert("soccer");
}
function v(){
alert("Volleyball");
}
function b(){	
alert("Baseball");
}
//4.
/*Aqui se cree 3 variables, la variable texto qué
 * contiene a document.getElementById se va a encargar
 * de obtener el id y el texto, la variable opción va a
 * contener a el texto que vamos a ingresar...
 * la variable lista va a obtener ese texto y
 * con lista.innerHTML va a imprimir el texto..
 * para que el texto aparezca en rojo encerré la
 * variable texto de esta forma "<p>"+texto+"<\p>"
 * y me dirijo al css y le doy estilo a "p"
 * y con color: red; se va a encargar que todos los
 * "p" que allán sea rojos.
 */
function red(){
texto = document.getElementById("nombre").value;
opcion ="<p>"+texto+"<\p>"
lista = document.getElementById("texto");
lista.innerHTML += opcion;
}

//5.
/*creo dos variables para cada número y con parseInt
 * estamos convirtiendo esa variable en un entero y
 * obtenemos los id de cada uno, que deben de ser diferentes
 * y se encuentran en el HTML y con value toma ese valor
 */
function num(){
num1 = parseInt(document.getElementById("num").value);
num2 = parseInt(document.getElementById("num2").value);

/* ahora las condiciones de que si el número 1 es mayor
que el número dos mostrará el mensaje de q es mayor
 si no lo es pasara a la siguiente condición y la
cumplirá y es falso y ambos son iguales pasará a la
tercera condición y mostrará la alert 
*/
if(num1 > num2)
alert("El mayor es: "+num1+" y el menor es: "+num2)
if(num2 > num1)
alert("El mayor es: "+num2+" y el menor es: "+num1)
if(num1 == num2)
alert("Son los mismos valores...")
}
            
//6.
/*cree aun función que continúe 3 variables una
se va a encargar que obtener el Id del input y el otro
el Id del ul encargado de hacer la lista desordenada
el opción va a contener el valor de la variable des
y encerrado en <li> para q salga cómo una lista y al
final imprimimos esa variable para mostrar el valor
*/
function li(){
des = document.getElementById("name").value;
opcion ="<li>"+des+"</li>"
lista = document.getElementById("desorden");
lista.innerHTML += opcion;
}
//7.
/*El mismo método de la 6 la use en la 7 algo a tener
 *en cuenta es que la etiqueta encargada de hacerla una
 * lista ordenada o desordenada está en el HTML con un id y 
 * estamos obteniendo ese valor con document.getElementById
 */
function ol(){
ord = document.getElementById("orden").value;
imp ="<li>"+ord+"</li>";
lista = document.getElementById("Orden");
lista.innerHTML += imp;
}
//8.
/*En esta función creo una variable que se va a encargar
 * de mostrarme un mensaje en pantalla en el cual voy a
 * poder ingresar un dato en este caso de edad
 */
function licencia(){
edad = prompt("Ingrese su edad: ");
/*Si la edad es mayor a 18 va a imprimir las alertas que tiene
si no pasará a la siguiente línea y imprimirá esas alertas
*/
if(edad > 18){
alert("Es mayor de edad")
alert("Ya puede licenciarse para conducir")
}
else{
alert("Aun es menor de edad");
alert("No puede licenciarse para conducir")
}
}
//9
/*en esta función Crea una variable qué me va a mostrar un mensaje en pantalla pidiéndome un dato
 * y dependiendo del dato insertado se cumplirá una función y activara una alerta
 */
function nota(){
  Nota = prompt("Ingrese Su Nota: ");
  if(Nota <=3)
	alert("Nota Muy deficiente")
	if(Nota >3 && Nota <=5)
	alert("Nota Insuficiente")
	if(Nota >5 && Nota <=6)
	alert("Nota Suficiente")
	if(Nota >6 && Nota <=7)
	alert("Nota Bien")
	if(Nota >7 && Nota <=9)
	alert("Nota Notable")
	if(Nota >9 && Nota <=10)
	alert("Nota Sobresaliente")
}
//10.
/*esta función está encargada declara una pirámide
El primer for se va a encargar de imprimir números
empezando en 1 y finalizando en 30, el segundo for
va a hacer que el primer for duplique cada número
el 1 una vez en 2 dos veces asi sucesivamente luego
empezamos a mostrar esos valores
*/
function piramide(){
for (var a = 1; a <= 30; a++) {
for (var e = 0; e < a; e++){
//imprimira la variable a
document.write(a);
}
//imprimirá un salto de línea para separar los números..
document.write("<br>");
}
}

//11.
/*esta función se va a encargar de pedirme 3 nombres
 * con sus edades y el condicional if va a comparar
 * las edades y imprimira el nombre del mayor con su edad
 * 
 */
function mayor(){
N1 =prompt("Su nombre: ");
ed1 = parseInt(prompt("Su edad: "));
N2 =prompt("otro nombre: ");
ed2 = parseInt(prompt("Su edad: "));
N3 =prompt("Otro nombre ");
ed3 = parseInt(prompt("Su edad: "));

if(ed1 > ed2 && ed1 > ed3){
alert("El mayor es: "+N1+" con "+ed1+" años");
}
if(ed2 > ed1 && ed2 > ed3){
alert("El mayor es: "+N2+" con "+ed2+" años");
}
if(ed3 > ed1 && ed3 > ed2){
alert("El mayor es: "+N3+" con "+ed3+" años");
}
}